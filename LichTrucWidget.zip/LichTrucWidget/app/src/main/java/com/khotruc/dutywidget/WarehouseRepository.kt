package com.khotruc.dutywidget

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Repository CHỈ ĐỌC (read-only). Không dùng Firebase Auth — app widget này
 * không có quyền admin, không ghi/sửa được bất kỳ dữ liệu nào.
 * Yêu cầu Firestore Rules cho phép `allow read: if true;` trên collection
 * `warehouses` (xem README.md mục BƯỚC 3).
 */
object WarehouseRepository {

    private const val COLLECTION = "warehouses"

    private val db: FirebaseFirestore
        get() = FirebaseFirestore.getInstance()

    /** Lấy danh sách tất cả các kho để hiển thị màn hình "Chọn kho". */
    suspend fun listWarehouses(): List<WarehouseData> {
        val snapshot = db.collection(COLLECTION).get().await()
        return snapshot.documents.mapNotNull { doc ->
            doc.toObject(WarehouseData::class.java)?.apply { id = doc.id }
        }.sortedBy { it.name }
    }

    /** Lấy dữ liệu 1 kho theo id (uid admin) — dùng để refresh widget / mở bảng đầy đủ. */
    suspend fun getWarehouse(warehouseId: String): WarehouseData? {
        val doc = db.collection(COLLECTION).document(warehouseId).get().await()
        if (!doc.exists()) return null
        return doc.toObject(WarehouseData::class.java)?.apply { id = doc.id }
    }
}
