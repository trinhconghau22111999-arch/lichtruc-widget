package com.khotruc.dutywidget

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.khotruc.dutywidget.databinding.ItemKhoBinding

class KhoAdapter(
    private val items: List<WarehouseData>,
    private val onClick: (WarehouseData) -> Unit
) : RecyclerView.Adapter<KhoAdapter.KhoViewHolder>() {

    inner class KhoViewHolder(val binding: ItemKhoBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KhoViewHolder {
        val binding = ItemKhoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return KhoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: KhoViewHolder, position: Int) {
        val item = items[position]
        val displayName = item.name.ifBlank { "Kho chưa đặt tên" }
        holder.binding.khoName.text = displayName
        holder.binding.khoAdminId.text = "Admin: ${item.adminId}"
        holder.binding.root.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size
}
