package com.khotruc.dutywidget

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.khotruc.dutywidget.databinding.ItemScheduleDayBinding
import java.time.LocalDate

/**
 * Danh sách CHỈ XEM cho bảng "Lịch trực sắp tới" — không có EditText/nút sửa
 * nào, khác hẳn bảng admin bên web (nơi có thể bấm bút chì để sửa).
 */
class ScheduleAdapter(
    private val days: List<LocalDate>,
    private val data: WarehouseData
) : RecyclerView.Adapter<ScheduleAdapter.DayViewHolder>() {

    inner class DayViewHolder(val binding: ItemScheduleDayBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayViewHolder {
        val binding = ItemScheduleDayBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DayViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DayViewHolder, position: Int) {
        val date = days[position]
        val idx = DutyLogic.groupIndexForDate(data, date)
        val b = holder.binding

        b.dayDate.text = DutyLogic.fmtDate(date)
        b.dayWeekday.text = DutyLogic.WEEKDAYS_VN[date.dayOfWeek.value % 7]

        if (idx < 0) {
            b.dayGroupLabel.text = "—"
            b.dayColorDot.visibility = android.view.View.GONE
            b.dayOverrideTag.visibility = android.view.View.GONE
            b.dayNames.text = holder.itemView.context.getString(R.string.no_data)
            return
        }

        b.dayColorDot.visibility = android.view.View.VISIBLE
        val color = Color.parseColor(DutyLogic.groupColor(idx))
        (b.dayColorDot.background.mutate() as GradientDrawable).setColor(color)
        b.dayGroupLabel.text = DutyLogic.groupLabel(idx)

        val overridden = DutyLogic.isOverriddenDate(data, date)
        b.dayOverrideTag.visibility = if (overridden) android.view.View.VISIBLE else android.view.View.GONE

        val members = DutyLogic.displayMembersForDate(data, date)
        b.dayNames.text = if (members.isEmpty()) {
            holder.itemView.context.getString(R.string.no_name)
        } else {
            members.joinToString("\n") { "—  $it" }
        }
    }

    override fun getItemCount(): Int = days.size
}
