package com.khotruc.dutywidget

/**
 * Khớp 1-1 với cấu trúc document Firestore mà bản web admin (index.html) đang lưu:
 * {
 *   name: string,
 *   adminId: string,
 *   groupCount: number,
 *   groups: [ { memberCount:number, members:[string,...] }, ... ],
 *   startDate: "YYYY-MM-DD",
 *   startGroupIndex: number,
 *   overrides: { "YYYY-MM-DD": [string,...], ... }
 * }
 *
 * Dùng "no-arg constructor + var + default value" để Firestore SDK có thể tự
 * ánh xạ (toObject) mà không cần custom deserializer.
 */
data class GroupData(
    var memberCount: Int = 1,
    var members: List<String> = emptyList()
)

data class WarehouseData(
    var name: String = "",
    var adminId: String = "",
    var groupCount: Int = 0,
    var groups: List<GroupData> = emptyList(),
    var startDate: String = "",
    var startGroupIndex: Int = 0,
    var overrides: Map<String, List<String>> = emptyMap()
) {
    // id của document (uid admin) — set thủ công sau khi query, không nằm trong Firestore field
    var id: String = ""
}
