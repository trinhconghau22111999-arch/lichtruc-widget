package com.khotruc.dutywidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.khotruc.dutywidget.databinding.ActivityWidgetConfigureBinding
import kotlinx.coroutines.launch

/**
 * Màn hình hiện ra khi người dùng nhấn giữ màn hình chính -> Widget -> kéo thả
 * "Lịch Trực Widget" vào màn hình. Android tự động mở Activity này (khai báo
 * qua android:configure trong widget_info.xml + intent-filter APPWIDGET_CONFIGURE
 * trong AndroidManifest).
 *
 * Đây là bước "đăng nhập" duy nhất của app: chỉ cần CHỌN ĐÚNG KHO, không cần
 * mật khẩu admin. Không có quyền chỉnh sửa ở màn hình này hay bất kỳ đâu khác.
 */
class WidgetConfigureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWidgetConfigureBinding
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Nếu người dùng bấm Back/thoát ngang chừng, Android sẽ không thêm widget (mặc định RESULT_CANCELED)
        setResult(Activity.RESULT_CANCELED)

        binding = ActivityWidgetConfigureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        binding.configureRecycler.layoutManager = LinearLayoutManager(this)
        loadWarehouses()
    }

    private fun loadWarehouses() {
        binding.configureProgress.visibility = android.view.View.VISIBLE
        binding.configureEmptyText.visibility = android.view.View.GONE

        lifecycleScope.launch {
            try {
                val list = WarehouseRepository.listWarehouses()
                binding.configureProgress.visibility = android.view.View.GONE
                if (list.isEmpty()) {
                    binding.configureEmptyText.visibility = android.view.View.VISIBLE
                } else {
                    binding.configureRecycler.adapter = KhoAdapter(list) { selected ->
                        onWarehouseChosen(selected)
                    }
                }
            } catch (e: Exception) {
                binding.configureProgress.visibility = android.view.View.GONE
                binding.configureEmptyText.visibility = android.view.View.VISIBLE
                binding.configureEmptyText.text = getString(R.string.load_error)
            }
        }
    }

    private fun onWarehouseChosen(warehouse: WarehouseData) {
        WidgetPrefs.saveWarehouseForWidget(this, appWidgetId, warehouse.id)

        // Yêu cầu widget cập nhật ngay với dữ liệu của kho vừa chọn
        val appWidgetManager = AppWidgetManager.getInstance(this)
        DutyWidgetProvider.updateAppWidget(this, appWidgetManager, appWidgetId)

        // Đảm bảo lịch làm mới nền (mỗi 15 phút, không thông báo) đã được đăng ký
        DutySyncWorker.schedule(this)

        val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        setResult(Activity.RESULT_OK, resultValue)
        finish()
    }
}
