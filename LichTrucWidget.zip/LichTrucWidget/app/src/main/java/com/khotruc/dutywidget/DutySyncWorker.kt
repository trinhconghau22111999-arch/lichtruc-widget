package com.khotruc.dutywidget

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Công việc nền chạy định kỳ (qua WorkManager) để làm mới 3 hàng ngoài widget, KHÔNG cần
 * foreground service, KHÔNG cần thông báo nền, KHÔNG cần xin thêm quyền gì cả.
 *
 * Đánh đổi so với lắng nghe realtime: có độ trễ tối đa ~15 phút (đây là chu kỳ NGẮN NHẤT mà
 * Android cho phép đối với PeriodicWorkRequest — không thể đặt thấp hơn, kể cả muốn). Widget
 * đã có sẵn lớp bảo hiểm updatePeriodMillis 30 phút trong widget_info.xml; worker này chạy
 * thêm 1 lớp dày hơn (15 phút) để rút ngắn khoảng lệch tối đa xuống còn một nửa, cộng với vẫn
 * đồng bộ ngay mỗi khi mở/đóng trang "Xem thêm" hoặc bấm tay vào widget.
 */
class DutySyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            DutyWidgetProvider.refreshAllWidgetsAwait(applicationContext)
            Result.success()
        } catch (e: Exception) {
            // Có thể do mất mạng tạm thời -> để WorkManager tự thử lại sau, không cần báo lỗi ồn ào
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "duty_sync_periodic_work"
        private const val INTERVAL_MINUTES = 15L // mức tối thiểu Android cho phép với periodic work

        /** Đăng ký lịch chạy nền định kỳ (gọi khi có widget đầu tiên được thêm vào màn hình). */
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<DutySyncWorker>(INTERVAL_MINUTES, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()

            // KEEP: nếu đã có lịch đang chạy rồi thì giữ nguyên, không tạo trùng lặp.
            // WorkManager tự lưu lịch này bền vững qua khởi động lại máy, không cần BootReceiver riêng.
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        /** Huỷ lịch chạy nền (gọi khi widget cuối cùng bị gỡ khỏi màn hình chính). */
        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
