package com.khotruc.dutywidget

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.khotruc.dutywidget.databinding.ActivityMainBinding

/**
 * App này KHÔNG có màn hình đăng nhập admin, KHÔNG có chức năng chỉnh sửa.
 * Mở icon app trực tiếp chỉ để xem hướng dẫn thêm Widget vào màn hình chính.
 * Toàn bộ việc xem lịch trực thực tế diễn ra ở Widget + màn hình "Xem thêm"
 * (DetailActivity) — cả hai đều chỉ đọc dữ liệu, không có nút sửa nào.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}
