package com.khotruc.dutywidget

import android.content.Context

/**
 * Lưu ánh xạ appWidgetId -> warehouseId (id của "kho" đã chọn khi thêm widget).
 * Mỗi widget trên màn hình chính có thể chọn kho khác nhau nếu muốn (ví dụ
 * quản lý nhiều kho, mỗi kho 1 widget riêng).
 */
object WidgetPrefs {
    private const val PREFS_NAME = "duty_widget_prefs"
    private const val KEY_PREFIX = "warehouse_for_widget_"

    fun saveWarehouseForWidget(context: Context, appWidgetId: Int, warehouseId: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PREFIX + appWidgetId, warehouseId)
            .apply()
    }

    fun getWarehouseForWidget(context: Context, appWidgetId: Int): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_PREFIX + appWidgetId, null)
    }

    fun removeWarehouseForWidget(context: Context, appWidgetId: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_PREFIX + appWidgetId)
            .apply()
    }
}
