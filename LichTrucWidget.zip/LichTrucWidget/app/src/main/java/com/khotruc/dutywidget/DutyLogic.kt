package com.khotruc.dutywidget

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

/**
 * Toàn bộ hàm dưới đây là port lại 1:1 (không đổi công thức) từ phần JS bên
 * web admin (index.html): dayIndexFor, groupIndexForDate, groupMembersDisplay,
 * displayMembersForDate, isOverriddenDate, dateKeyOf, fmtDate, WEEKDAYS_VN,
 * GROUP_COLORS. Mục đích: đảm bảo widget hiển thị khớp 100% với bảng web,
 * vì cùng 1 công thức xoay vòng nhóm.
 */
object DutyLogic {

    val WEEKDAYS_VN = arrayOf(
        "Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"
    )

    val GROUP_COLORS = arrayOf(
        "#FFC93C", "#FF6B35", "#2EC4B6", "#3A86FF",
        "#FF4D6D", "#8338EC", "#06D6A0", "#FB8B24"
    )

    fun groupColor(i: Int): String = GROUP_COLORS[((i % GROUP_COLORS.size) + GROUP_COLORS.size) % GROUP_COLORS.size]

    fun groupLabel(i: Int): String = "Nhóm " + (i + 1)

    private val dateKeyFormatter: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE // yyyy-MM-dd

    fun dateKeyOf(date: LocalDate): String = date.format(dateKeyFormatter)

    fun fmtDate(date: LocalDate): String {
        val dd = date.dayOfMonth.toString().padStart(2, '0')
        val mm = date.monthValue.toString().padStart(2, '0')
        return "$dd/$mm/${date.year}"
    }

    /** Chuyển field startDate (chuỗi "YYYY-MM-DD" lưu trên Firestore) thành LocalDate an toàn. */
    fun parseStartDate(startDate: String): LocalDate {
        return try {
            // startDate có thể có phần giờ (nếu lưu dạng ISO datetime) -> chỉ lấy 10 ký tự đầu
            val onlyDate = if (startDate.length >= 10) startDate.substring(0, 10) else startDate
            LocalDate.parse(onlyDate)
        } catch (e: Exception) {
            LocalDate.now()
        }
    }

    private fun dayIndexFor(data: WarehouseData, target: LocalDate): Long {
        val start = parseStartDate(data.startDate)
        return ChronoUnit.DAYS.between(start, target)
    }

    fun groupIndexForDate(data: WarehouseData, date: LocalDate): Int {
        val n = data.groupCount
        if (n < 1) return -1
        val idx = dayIndexFor(data, date).toInt()
        return (((data.startGroupIndex + idx) % n) + n) % n
    }

    fun groupMembersDisplay(data: WarehouseData, groupIdx: Int): List<String> {
        if (groupIdx < 0 || groupIdx >= data.groups.size) return emptyList()
        return data.groups[groupIdx].members.filter { it.isNotBlank() }
    }

    fun defaultMembersForDate(data: WarehouseData, date: LocalDate): List<String> {
        val idx = groupIndexForDate(data, date)
        if (idx < 0) return emptyList()
        return groupMembersDisplay(data, idx)
    }

    /** Danh sách tên hiển thị cho 1 ngày cụ thể — ưu tiên override riêng ngày đó nếu có. */
    fun displayMembersForDate(data: WarehouseData, date: LocalDate): List<String> {
        val key = dateKeyOf(date)
        val ov = data.overrides[key]
        return ov ?: defaultMembersForDate(data, date)
    }

    fun isOverriddenDate(data: WarehouseData, date: LocalDate): Boolean {
        return data.overrides.containsKey(dateKeyOf(date))
    }
}
