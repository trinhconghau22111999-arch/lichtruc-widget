package com.khotruc.dutywidget

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.khotruc.dutywidget.databinding.ActivityDetailBinding
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * Màn hình "Xem thêm" — mở ra khi bấm hàng thứ 4 trên widget.
 * Hiển thị NGUYÊN bảng lịch trực 30 ngày, y hệt bảng cuối trang admin web,
 * nhưng KHÔNG có cây bút chỉnh sửa, KHÔNG có TextInput nào — chỉ đọc.
 */
class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_WAREHOUSE_ID = "extra_warehouse_id"
        private const val SCHEDULE_DAYS = 30
    }

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.detailRecycler.layoutManager = LinearLayoutManager(this)

        val warehouseId = intent.getStringExtra(EXTRA_WAREHOUSE_ID)
        if (warehouseId.isNullOrBlank()) {
            showError()
            return
        }
        loadSchedule(warehouseId)
    }

    private fun loadSchedule(warehouseId: String) {
        binding.detailProgress.visibility = android.view.View.VISIBLE
        binding.detailErrorText.visibility = android.view.View.GONE

        lifecycleScope.launch {
            try {
                val data = WarehouseRepository.getWarehouse(warehouseId)
                binding.detailProgress.visibility = android.view.View.GONE
                if (data == null) {
                    showError()
                    return@launch
                }
                binding.detailWarehouseName.text = data.name.ifBlank { "Kho chưa đặt tên" }
                val today = LocalDate.now()
                val days = (0 until SCHEDULE_DAYS).map { today.plusDays(it.toLong()) }
                binding.detailRecycler.adapter = ScheduleAdapter(days, data)
            } catch (e: Exception) {
                binding.detailProgress.visibility = android.view.View.GONE
                showError()
            }
        }
    }

    private fun showError() {
        binding.detailErrorText.visibility = android.view.View.VISIBLE
    }
}
