# Lịch Trực Widget — Hướng dẫn cài đặt & build APK

App này là **widget màn hình chính** (giống widget đồng hồ) — chỉ xem, KHÔNG có quyền admin,
KHÔNG chỉnh sửa được gì. Hiển thị 3 ngày gần nhất (Hôm nay / Ngày mai / Ngày mốt) theo cột dọc,
hàng thứ 4 là "Xem thêm ›" — bấm vào mở bảng đầy đủ 30 ngày (chỉ xem).

---

## BƯỚC 1 — Cài Android Studio

1. Vào https://developer.android.com/studio → tải bản cho Windows/Mac.
2. Cài đặt bình thường (Next → Next → Finish), lần đầu mở nó sẽ tự tải thêm
   Android SDK — cứ để nó tải xong (cần internet, khoảng 10–20 phút).
3. Mở Android Studio → **Open** → chọn thư mục `LichTrucWidget` (thư mục chứa file này).
4. Đợi Gradle sync lần đầu (thanh progress dưới đáy màn hình) — có thể mất vài phút.
5. Nếu Android Studio hiện thông báo kiểu "Gradle wrapper is missing, create it?" hoặc
   tương tự → bấm **OK/Yes** để nó tự tạo — đây là bình thường, không phải lỗi.

## BƯỚC 2 — Đăng ký thêm 1 "app Android" trong Firebase project cũ

Project Firebase hiện tại của bạn đã có tên là `lichtruckho` (đang dùng cho web admin).
Giờ cần đăng ký thêm 1 app Android **mới** trong CHÍNH project đó (không tạo project mới):

1. Vào https://console.firebase.google.com → chọn project **lichtruckho**.
2. Bấm **⚙️ Project settings** → kéo xuống **Your apps** → bấm biểu tượng Android để **Add app**.
3. Package name: nhập chính xác `com.khotruc.dutywidget`
4. App nickname: "Lịch trực Widget" (tuỳ ý).
5. Không cần điền SHA-1 (bỏ qua bước đó, bấm Next).
6. Bấm **Download google-services.json** → lưu file này lại.
7. Copy file `google-services.json` vừa tải vào đúng thư mục:
   `LichTrucWidget/app/google-services.json`
   (ngang hàng với file `app/build.gradle`)

## BƯỚC 3 — Cập nhật Firestore Rules (cho phép app widget đọc dữ liệu)

Vì app widget này KHÔNG đăng nhập admin (không mật khẩu), Firestore cần cho phép **đọc**
(read) công khai collection `warehouses` để app biết danh sách "kho" và lấy lịch trực.
Việc **ghi/sửa** vẫn chỉ chủ tài khoản admin mới làm được (như cũ).

Vào Firebase Console → **Firestore Database** → tab **Rules** → dán đúng nội dung sau
(thay thế toàn bộ nội dung cũ) rồi bấm **Publish**:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /warehouses/{warehouseId} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == warehouseId;
    }
  }
}
```

⚠️ Lưu ý: sau khi áp dụng rule này, **ai cài app widget cũng xem được lịch trực của MỌI
kho** (chỉ xem, không sửa được — ghi/sửa vẫn cần đăng nhập admin đúng tài khoản như bên web).
Bạn đã đồng ý điều này rồi nên mình để mặc định vậy. Nếu sau này muốn đổi ý (ví dụ thêm mã
PIN riêng cho từng kho), cứ nhắn lại.

## BƯỚC 4 — Build ra file APK

Trong Android Studio:

- **Cách nhanh (APK debug, cài thử ngay được, không cần ký):**
  Menu **Build** → **Build App Bundle(s) / APK(s)** → **Build APK(s)**.
  Sau khi build xong, sẽ có thông báo nhỏ góc dưới phải màn hình — bấm **locate**
  để mở thư mục chứa file, thường ở:
  `LichTrucWidget/app/build/outputs/apk/debug/app-debug.apk`
  → copy file này vào điện thoại (qua cáp USB, Zalo gửi mình, Google Drive...) rồi cài.

- **Cách chuẩn hơn (APK release, để cài lâu dài):**
  Menu **Build** → **Generate Signed Bundle / APK...** → chọn **APK** → **Next**
  → bấm **Create new...** để tạo keystore mới (nhớ lưu lại file `.jks` và mật khẩu,
  cần dùng lại mỗi lần build sau này) → Next → chọn `release` → Finish.
  File APK sẽ nằm ở `app/build/outputs/apk/release/app-release.apk`.

## BƯỚC 5 — Cài & dùng trên điện thoại

1. Trên điện thoại, vào **Cài đặt → Bảo mật** → bật **Cài ứng dụng từ nguồn không xác định**
   (Install unknown apps) cho app bạn dùng để mở file APK (ví dụ File Manager/Zalo).
2. Bấm vào file `.apk` → **Cài đặt**.
3. Sau khi cài xong, **nhấn giữ tay vào màn hình chính (Home)** → chọn **Widget** →
   tìm "Lịch Trực Widget" → kéo thả ra màn hình chính.
4. Lần đầu thêm widget, màn hình chọn **"Chọn kho"** sẽ hiện ra → chọn đúng tên kho của bạn
   → widget hiển thị ngay 3 ngày gần nhất + hàng "Xem thêm ›".
5. Bấm "Xem thêm ›" → mở bảng đầy đủ 30 ngày (chỉ xem, không sửa được gì).

Widget tự làm mới dữ liệu mỗi ~30 phút (giới hạn tối thiểu của Android cho widget).
Bạn cũng có thể bấm vào dòng "Hôm nay" trên widget để làm mới ngay lập tức.

---

### Ghi chú kỹ thuật (nếu bạn muốn hiểu code)
- Không dùng Firebase Auth — app đọc thẳng Firestore theo rule public-read ở BƯỚC 3.
- Logic tính "nhóm nào trực ngày nào" (`DutyLogic.kt`) được viết lại y hệt logic bên
  web (`groupIndexForDate`, `displayMembersForDate`, `overrides`...) để đảm bảo khớp
  100% với bảng bên web admin.
- Widget dùng `AppWidgetProvider` + `RemoteViews` (không phải "bong bóng nổi" đè lên app khác).
- File cấu hình widget: `res/xml/widget_info.xml`.
