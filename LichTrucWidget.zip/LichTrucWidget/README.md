# Lịch Trực Widget — Hướng dẫn (bản gọn, dùng GitHub — KHÔNG cần cài Android Studio)

App này là **widget màn hình chính** (giống widget đồng hồ) — chỉ xem, không có quyền
admin, không sửa được gì. 3 ngày gần nhất theo cột dọc + hàng 4 "Xem thêm ›" mở bảng
đầy đủ 30 ngày (cũng chỉ xem).

Vì bạn đã có GitHub sẵn, cách gọn nhất là để **GitHub tự động build APK giúp bạn**
(dự án đã có sẵn file `.github/workflows/build-apk.yml` làm việc này) — bạn không cần
cài Android Studio, không cần Gradle, không cần build gì trên máy cả.

---

## CHỈ 4 BƯỚC

### 1) Lấy `google-services.json` (bắt buộc, ~2 phút)
- Vào https://console.firebase.google.com → chọn project **lichtruckho**.
- ⚙️ Project settings → **Your apps** → bấm icon Android → **Add app**.
- Package name: `com.khotruc.dutywidget` → Next → Next (bỏ qua SHA-1) → **Download google-services.json**.

### 2) Cho phép widget đọc dữ liệu (bắt buộc, ~1 phút)
- Firebase Console → **Firestore Database** → tab **Rules** → dán đè bằng đúng nội dung sau → **Publish**:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /warehouses/{warehouseId} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == warehouseId;
    }
  }
}
```
(Ai cài app cũng xem được lịch mọi kho, chỉ xem không sửa được — bạn đã đồng ý điều này rồi.)

### 3) Đẩy code lên GitHub
- Tạo 1 repo mới (public hoặc private đều được) trên GitHub, ví dụ tên `lichtruc-widget`.
- Upload TOÀN BỘ nội dung thư mục `LichTrucWidget` (đã giải nén) lên repo đó —
  cách dễ nhất: vào trang repo trên GitHub → **Add file → Upload files** → kéo thả
  hết vào (kéo cả các thư mục con).
- Bỏ file `google-services.json` bạn tải ở bước 1 vào đúng vị trí **`app/google-services.json`**
  rồi upload luôn (nếu upload web không giữ cấu trúc thư mục con, tạo file mới trong
  GitHub web tại đường dẫn `app/google-services.json` rồi copy-dán nội dung vào).

### 4) Lấy file APK
- Vào tab **Actions** trên trang repo GitHub → sẽ thấy workflow "Build APK" đang chạy
  (tự chạy sau khi bạn upload xong) → đợi khoảng 3–5 phút tới khi có dấu ✅ xanh.
- Bấm vào lần chạy đó → kéo xuống mục **Artifacts** → tải **app-debug-apk** về
  (file zip, giải nén ra sẽ thấy file `app-debug.apk`).
- Copy file `.apk` này vào điện thoại → bật **Cài ứng dụng nguồn không xác định** → cài.
- Nhấn giữ màn hình Home → **Widget** → tìm "Lịch Trực Widget" → kéo ra → chọn đúng kho.

---

## Nếu Actions báo lỗi đỏ (❌)
Bấm vào lần chạy lỗi → xem log màu đỏ, thường là do quên bỏ `google-services.json`
đúng chỗ, hoặc file bị lỗi định dạng. Chụp màn hình log gửi mình, mình đọc và sửa giúp.

## Cách khác (nếu bạn thích build trên máy, không dùng GitHub)
Vẫn build được bằng Android Studio như bình thường — mở project này trong Android
Studio, Build → Build APK(s). Không bắt buộc, chỉ là lựa chọn thêm nếu muốn.

---

### Ghi chú kỹ thuật
- `DutyLogic.kt` — công thức xoay vòng nhóm y hệt bên web (groupIndexForDate, override từng ngày...).
- Không dùng Firebase Auth, chỉ đọc Firestore theo rule public-read ở bước 2.
- Widget = `AppWidgetProvider` + `RemoteViews`, không phải bong bóng nổi đè app khác.
