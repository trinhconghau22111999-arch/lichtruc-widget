package com.khotruc.dutywidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * Widget màn hình chính — CHỈ XEM. Không có bất kỳ nút/thao tác nào để chỉnh
 * sửa tên người trực, nhóm, hay bất kỳ dữ liệu nào. Hiển thị 3 ngày gần nhất
 * theo cột dọc (Hôm nay / Ngày mai / Ngày mốt); hàng thứ 4 "Xem thêm ›" mở
 * DetailActivity xem bảng đầy đủ 30 ngày (cũng chỉ xem).
 */
class DutyWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            WidgetPrefs.removeWarehouseForWidget(context, appWidgetId)
        }
    }

    companion object {

        // Scope riêng cho widget provider — chỉ dùng để fetch dữ liệu đọc (read-only) rồi cập nhật RemoteViews.
        private val widgetScope = CoroutineScope(Dispatchers.IO)

        /**
         * Ép TẤT CẢ widget trên màn hình chính tải lại dữ liệu mới nhất từ Firestore ngay lập tức.
         *
         * Lý do cần hàm này: widget chỉ tự làm mới theo updatePeriodMillis (tối thiểu 30 phút,
         * thực tế Android có thể trì hoãn lâu hơn do Doze/battery saver). Vì vậy nếu chỉ dựa vào
         * updatePeriodMillis, 3 hàng "Hôm nay/Ngày mai/Ngày mốt" trên widget sẽ hiển thị dữ liệu
         * cũ trong khi trang "Xem thêm" (DetailActivity) luôn fetch mới mỗi lần mở -> lệch nhau.
         * Gọi hàm này ngay sau khi DetailActivity tải xong dữ liệu mới để đồng bộ widget với đúng
         * dữ liệu vừa hiển thị ở trang "Xem thêm".
         */
        fun refreshAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, DutyWidgetProvider::class.java)
            val ids = appWidgetManager.getAppWidgetIds(componentName)
            for (id in ids) {
                updateAppWidget(context, appWidgetManager, id)
            }
        }

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val warehouseId = WidgetPrefs.getWarehouseForWidget(context, appWidgetId)
            val views = RemoteViews(context.packageName, R.layout.widget_layout)

            if (warehouseId.isNullOrBlank()) {
                views.setTextViewText(R.id.widget_warehouse_name, "Chưa chọn kho")
                views.setTextViewText(R.id.widget_day1_names, "Vui lòng xoá và thêm lại widget để chọn kho.")
                views.setTextViewText(R.id.widget_day2_names, "—")
                views.setTextViewText(R.id.widget_day3_names, "—")
                appWidgetManager.updateAppWidget(appWidgetId, views)
                return
            }

            // Hiện tạm trạng thái đang tải trong lúc chờ Firestore trả dữ liệu
            views.setTextViewText(R.id.widget_day1_names, context.getString(R.string.loading))
            appWidgetManager.updateAppWidget(appWidgetId, views)

            widgetScope.launch {
                try {
                    val data = WarehouseRepository.getWarehouse(warehouseId)
                    val freshViews = RemoteViews(context.packageName, R.layout.widget_layout)
                    if (data == null) {
                        freshViews.setTextViewText(R.id.widget_warehouse_name, "Không tìm thấy kho")
                        freshViews.setTextViewText(R.id.widget_day1_names, "—")
                        freshViews.setTextViewText(R.id.widget_day2_names, "—")
                        freshViews.setTextViewText(R.id.widget_day3_names, "—")
                        appWidgetManager.updateAppWidget(appWidgetId, freshViews)
                        return@launch
                    }
                    bindData(context, freshViews, data)
                    setupClickIntents(context, freshViews, appWidgetId, warehouseId)
                    appWidgetManager.updateAppWidget(appWidgetId, freshViews)
                } catch (e: Exception) {
                    val errViews = RemoteViews(context.packageName, R.layout.widget_layout)
                    errViews.setTextViewText(R.id.widget_day1_names, context.getString(R.string.load_error))
                    setupClickIntents(context, errViews, appWidgetId, warehouseId)
                    appWidgetManager.updateAppWidget(appWidgetId, errViews)
                }
            }
        }

        private fun bindData(context: Context, views: RemoteViews, data: WarehouseData) {
            val today = LocalDate.now()
            val tomorrow = today.plusDays(1)
            val dayAfter = today.plusDays(2)

            views.setTextViewText(R.id.widget_warehouse_name, data.name.ifBlank { "Lịch trực" })

            bindDayRow(context, views, R.id.widget_day1_label, R.id.widget_day1_names, "Hôm nay", today, data)
            bindDayRow(context, views, R.id.widget_day2_label, R.id.widget_day2_names, "Ngày mai", tomorrow, data)
            bindDayRow(context, views, R.id.widget_day3_label, R.id.widget_day3_names, "Ngày mốt", dayAfter, data)
        }

        private fun bindDayRow(
            context: Context,
            views: RemoteViews,
            labelId: Int,
            namesId: Int,
            labelText: String,
            date: LocalDate,
            data: WarehouseData
        ) {
            val idx = DutyLogic.groupIndexForDate(data, date)
            val members = if (idx >= 0) DutyLogic.displayMembersForDate(data, date) else emptyList()
            val groupPart = if (idx >= 0) "${DutyLogic.groupLabel(idx)} — " else ""
            val namesPart = if (members.isEmpty()) context.getString(R.string.no_name) else members.joinToString(", ")
            views.setTextViewText(labelId, "$labelText · ${DutyLogic.fmtDate(date)}")
            views.setTextViewText(namesId, groupPart + namesPart)
        }

        private fun setupClickIntents(context: Context, views: RemoteViews, appWidgetId: Int, warehouseId: String) {
            // Bấm hàng "Xem thêm" -> mở bảng đầy đủ 30 ngày (chỉ xem)
            val detailIntent = Intent(context, DetailActivity::class.java).apply {
                putExtra(DetailActivity.EXTRA_WAREHOUSE_ID, warehouseId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val detailPendingIntent = PendingIntent.getActivity(
                context, appWidgetId, detailIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_see_more, detailPendingIntent)

            // Bấm vào tên kho / hàng "Hôm nay" -> làm mới dữ liệu ngay lập tức
            val refreshIntent = Intent(context, DutyWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(appWidgetId))
            }
            val refreshPendingIntent = PendingIntent.getBroadcast(
                context, appWidgetId + 100000, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_warehouse_name, refreshPendingIntent)
            views.setOnClickPendingIntent(R.id.widget_row_today, refreshPendingIntent)
            views.setOnClickPendingIntent(R.id.widget_row_tomorrow, refreshPendingIntent)
            views.setOnClickPendingIntent(R.id.widget_row_dayafter, refreshPendingIntent)
        }
    }
}
